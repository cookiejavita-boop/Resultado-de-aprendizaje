# Revisión previa a la entrega

Esta revisión aplica el checklist original conservado en `docs/originales/Checklist_entrega_Hito1.docx`. Distingue lo comprobado durante la preparación de lo que depende de la publicación y revisión personal.

| Requisito | Evidencia y estado |
|---|---|
| Originales preservados | Comprobados byte por byte; siete copias registradas en `ORIGINALES.sha256`. |
| Unidades y conversiones | Explicadas en el README, en la planilla y en el método de la nota. |
| I, deflexión y comparación trazables | Fórmulas visibles en `Analisis`, referencias a `Datos` y fila de origen del CSV. |
| Figura con ambas series | Nueve observaciones por serie, ejes en kN y mm, leyenda y ruta hasta las celdas. |
| Verificación adicional | Revisión dimensional, cálculo independiente de 40 kN y δ/P. |
| Compilación y referencias | Compilación local con pdfLaTeX y BibTeX comprobada; **pendiente recompilar en Overleaf**. |
| README reproducible | Contiene entradas, procedimiento, salidas, software, unidades, supuestos y actualización de la figura. |
| Historial e identificación de versión | **Pendiente:** cargar en GitHub con commits y copiar el hash real de la entrega. |
| Uso de IA | Registrado en `USO_IA.md`; **pendiente revisión y conformidad personal del estudiante**. |
| PDF y ZIP corresponden al commit | PDF y fuente del paquete corresponden entre sí; **pendiente descargar el ZIP de la versión final publicada**. |

La generación y el recálculo de la planilla se verificaron con las herramientas de hojas de cálculo del asistente. **Pendiente:** abrir el XLSX en Microsoft Excel y confirmar las fórmulas y el gráfico en la aplicación que se utilizará para continuar el trabajo.

No se sustituyó la rúbrica de desempeño por esta lista. No se marcó como realizada una publicación en GitHub, una ejecución en la cuenta de Overleaf o una revisión humana que aún no se haya efectuado.
