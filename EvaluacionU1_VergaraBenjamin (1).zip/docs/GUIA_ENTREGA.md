# Publicar el proyecto y entregar el Hito 1

## 1. Revisar los archivos

Descomprima el ZIP. Las carpetas `data`, `analysis`, `figures`, `report` y `docs`, junto con `README.md` y `USO_IA.md`, deben quedar juntas. Si extrae todo dentro de una carpeta adicional, entre a ella antes de seleccionar el contenido que subirá.

Abra el Excel, revise los datos y las fórmulas y repita la fila de 40 kN. Lea la nota técnica. El nombre utilizado es **Benjamín Vergara**. Si debe cambiarlo, modifique `report/main.tex`, recompile y actualice también los nombres de los archivos de entrega.

Actualice el estado de revisión de `USO_IA.md` y `docs/REVISION.md` únicamente después de realizar las acciones correspondientes. La plantilla original está conservada en `docs/originales/`.

## 2. Cargar las carpetas en GitHub

Utilice un repositorio destinado a este Hito 1, por ejemplo `hito1-viga`, para que sus archivos se encuentren directamente en la estructura solicitada. En GitHub, pulse **Add file → Upload files** y arrastre las carpetas o archivos de cada etapa. Escriba un mensaje que describa lo que efectivamente está incorporando y pulse **Commit changes**.

| Etapa real de carga | Contenido | Mensaje sugerido |
|---|---|---|
| Preservación | `data/` y `docs/originales/` | `Conservar los datos y parámetros originales del Hito 1` |
| Análisis | `analysis/` | `Agregar cálculo de deflexión, conversiones y verificaciones` |
| Comunicación | `figures/` y `report/` | `Incorporar figura y nota técnica con referencias` |
| Documentación | `README.md`, `USO_IA.md` y los demás archivos de `docs/` | `Documentar reproducción, uso de IA y entrega` |

Estos mensajes son propuestas para cargas futuras, no un historial que ya exista. Los commits deben describir las acciones reales. Registre después cualquier revisión propia en un nuevo commit, por ejemplo `Aclarar la interpretación de la diferencia relativa`, cuando efectivamente haga esa modificación.

Para que GitHub muestre y conserve la estructura, **suba las carpetas descomprimidas y los archivos**, no solo el ZIP como un archivo dentro del repositorio. Verifique que se vean `data/datos_viga.csv`, `analysis/analisis_viga.xlsx` y `report/main.tex` en las rutas correctas. Mantenga los originales intactos.

## 3. PDF de entrega

Compile y revise `main.tex` en Overleaf siguiendo el README. Guarde la versión final como `report/nota_tecnica.pdf` y súbala a GitHub. La copia que adjuntará en Moodle debe llamarse:

`nota_tecnica_Hito1_VergaraBenjamin.pdf`

El PDF preparado en este paquete ya está compilado desde la fuente incluida. Si usted modifica el texto, el nombre, los cálculos o la figura, debe compilarlo nuevamente y reemplazar el PDF en GitHub antes de obtener el hash.

## 4. Hash y ZIP final

Después del último cambio, abra **Commits**, seleccione el commit más reciente de la rama entregada y copie su **hash completo** mediante **Copy full SHA**. El hash corresponde a esa versión de todos los archivos; cambiar un archivo y crear otro commit produce otra versión.

Desde ese commit, la opción **Browse files** permite ver el contenido de la versión seleccionada. Descargue su ZIP si GitHub muestra **Code → Download ZIP**. También puede utilizar **Code → Download ZIP** desde la rama principal inmediatamente después de comprobar que sigue apuntando a ese mismo último commit.

Renombre el ZIP descargado:

`EvaluacionU1_VergaraBenjamin.zip`

El ZIP preparado por el asistente sirve para publicar los archivos. Una vez publicado y revisado el repositorio, la entrega debe respaldar la versión real indicada por el hash. Si modifica algo después de descargar, obtenga nuevamente el ZIP y copie el hash actualizado.

## 5. Moodle

Adjunte los dos archivos con los nombres anteriores. En **Texto en línea**, pegue la URL real del repositorio y el hash completo copiado de GitHub. No utilice el hash del antiguo portafolio U1: este Hito 1 tiene archivos y resultados diferentes.

Si el repositorio es privado, habilite el acceso al equipo docente según las indicaciones de Moodle. Compruebe esa condición antes de enviar. El ZIP no conserva por sí solo el historial de commits.
